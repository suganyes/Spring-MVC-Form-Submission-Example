package org.sugan.yes.helloworld.controller.model;

import java.util.List;

public class Employee {

	private String Name;
	private String email;
	private String gender;
	private String password;
	private String passwordConf;
	private List<String> skills;
	private String passwordChallenge;
	private String passwordChallengeAnswer;

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getPasswordConf() {
		return passwordConf;
	}

	public void setPasswordConf(String passwordConf) {
		this.passwordConf = passwordConf;
	}

	public List<String> getSkills() {
		return skills;
	}

	public void setSkills(List<String> skills) {
		this.skills = skills;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public String getPasswordChallenge() {
		return passwordChallenge;
	}

	public void setPasswordChallenge(String passwordChallenge) {
		this.passwordChallenge = passwordChallenge;
	}

	public String getPasswordChallengeAnswer() {
		return passwordChallengeAnswer;
	}

	public void setPasswordChallengeAnswer(String passwordChallengeAnswer) {
		this.passwordChallengeAnswer = passwordChallengeAnswer;
	}
}
