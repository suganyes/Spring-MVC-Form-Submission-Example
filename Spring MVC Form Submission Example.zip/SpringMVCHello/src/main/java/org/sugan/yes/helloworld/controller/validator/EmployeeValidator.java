package org.sugan.yes.helloworld.controller.validator;

import java.util.List;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import org.sugan.yes.helloworld.controller.model.Employee;

public class EmployeeValidator implements Validator {

	private static final String EMAIL_PATTERN = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
	
	public boolean supports(Class<?> paramClass) {
		return Employee.class.equals(paramClass);
	}

	public void validate(Object obj, Errors errors) {
		Employee form = (Employee) obj;
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "name", "valid.name");
		if(!form.getEmail().matches(EMAIL_PATTERN)) {
			errors.rejectValue("email","valid.email");
		}
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "gender", "valid.gender");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "password", "valid.password");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "passwordConf", "valid.passwordConf");
		if (!form.getPassword().equals(form.getPasswordConf())) {
			errors.rejectValue("passwordConf", "valid.passwordConfDiff");
		}		
		List<String> skills = form.getSkills();
		if (skills == null || skills.size() < 2) {
			errors.rejectValue("skills", "valid.skills");
		}
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "passwordChallengeAnswer", "valid.passwordChallengeAnswer");
	}
}