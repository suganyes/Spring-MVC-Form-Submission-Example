package org.sugan.yes.helloworld.controller;
 
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.sugan.yes.helloworld.controller.model.Employee;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Validator;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
 
@Controller
@RequestMapping("/employee.htm")

public class EmployeeController {

	 @Autowired
	 @Qualifier("employeeValidator")
	    private Validator validator;
	    
	    @InitBinder
	    private void initBinder(WebDataBinder binder) {
	        binder.setValidator(validator);
	    }
	    
	@RequestMapping(method = RequestMethod.GET)
	public String initForm(Model model) {
		Employee employee = new Employee();
		employee.setPasswordChallenge("What is your Pet Name?");
		model.addAttribute("employee", employee);
		initModelList(model);
		return "employee";
	}

	@RequestMapping(method = RequestMethod.POST)
	public String submitForm(Model model, @Validated  Employee employee , BindingResult result) {
		model.addAttribute("employee", employee);
		String returnVal = "employeeDetails";
		if(result.hasErrors()) {
			initModelList(model);
			returnVal = "employee";
		} else {
			model.addAttribute("employee", employee);
		}	
		
		return returnVal;
	}

	private void initModelList(Model model) {
		List<String> skills = new ArrayList<String>();
		skills.add("Java");
		skills.add("Spring");
		skills.add("Hibernate");
		skills.add("Maven");
		skills.add("Webservices");
		model.addAttribute("skills", skills);
		
		List<String> genders = new ArrayList<String>();
		genders.add("Male");
		genders.add("Female");
		model.addAttribute("genders", genders);
		
		model.addAttribute("passwordChallenge", "What is your Pet's Name?");
		

	}
}